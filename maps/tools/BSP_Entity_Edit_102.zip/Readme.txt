*************************** 
     BSP Entity Edit
*************************** 

Name: BSP Entity Edit
Authors: SomaZ

File Name: BspEntityEdit.zip
File Size: ~21mb
Date Released : 06/10/2023

Credits: illwieckz for some lines of code, Jon Wright for pyopengltk, Insidious for his simple text editor tutorial

Description: This is an id tech 3 bsp entity editor. It can render opened bsp files with vertex colors, you can pick entities in the render with a simple click, you can edit the entity string, you can save the bsp file afterwards or choose to save as .ent file instead. The preview is updated when you click the button under the viewport.

Viewport Controlls:
W - Move camera forward
A - Move camera to the left
S - Move camera backwards
D - Move camera to the right
SPACE - Move camera upwards
C - Move camera downwards
LMC - Select Object under the cursor
RMC Hold and Drag - Rotate view
Mouse Scrolling - Move camera forwards or backwards
H - Hide currently selected entity
Alt-H - Unhide all entities
Esc - Deselect entity


* How to install * 
I build an exe for ease of use. It's build via pyinstaller with following command:

pyinstaller --noconfirm --onefile --windowed --name "BSP Entity Edit" --add-data "C:/Users/.../Desktop/BspEntityEdit/pyidtech3lib;pyidtech3lib/" --hidden-import "numpy" --hidden-import "ctypes" --hidden-import "pyopengltk" --add-data "C:/Users/.../Desktop/BspEntityEdit/edit_menu.py;." --add-data "C:/Users/.../Desktop/BspEntityEdit/file_menu.py;." --add-data "C:/Users/.../Desktop/BspEntityEdit/format_menu.py;." --add-data "C:/Users/.../Desktop/BspEntityEdit/help_menu.py;." --add-data "C:/Users/.../Desktop/BspEntityEdit/ogl_fbo.py;." --add-data "C:/Users/.../Desktop/BspEntityEdit/ogl_frame.py;." --add-data "C:/Users/.../Desktop/BspEntityEdit/ogl_objects.py;."  "C:/Users/.../Desktop/BspEntityEdit/main.py"

I included the full source code, so you can build it yourself or run it in your python environment of your choice. You need to install following packages to run the code: numpy, ctypes, pyopengltk
Tk must be installed too, but usually it's part of the standard python install
You can run the code afterwards with:

python main.py


Supported games (or at least tested game bsp files):
Star Wars Jedi Outcast
Star Wars Jedi Academy
Star Trek Elite Force
Quake 3
Xonotic

Update 06/18/2023:
- Shade surfaces in the viewport
- Surfaces with no lighting get a min lighting
- Added a render menu for changing antialiasing in the viewport
- Reworked preview window movement
- Fixed a bug where objects could overdraw trigger brushes in the viewport
- Text cursor now also selects objects in the viewport
- Changes to origin, angle, angles, modelscale and modelscale_vec keys should be updated immediately

Update 06/26/2023:
- Fixed a major bug that altered patch meshes in saved bsp files


* Copyright / Permissions * 
THIS FILE IS NOT MADE, DISTRIBUTED, OR SUPPORTED BY ACTIVISION PUBLISHING, INC., RAVEN SOFTWARE, OR LUCASARTS ENTERTAINMENT COMPANY, LLC. ELEMENTS� & � LUCASFILM LTD.� & DISNEY, INC.� AND/OR ITS LICENSORS. STAR WARS�, JEDI�, & JEDI KNIGHT� ARE REGISTERED TRADEMARKS OF LUCASFILM LTD� AND WALT DISNEY, INC.� STAR WARS�, JEDI�, & JEDI KNIGHT� ARE REGISTERED TRADEMARKS OF LUCASFILM LTD� & DISNEY, INC.�